<?php
include("db.php");
$uname=$_GET['uname'];
$query="DELETE FROM users WHERE uname='$uname'";
$conn=getConnection();

$data=mysqli_query($conn,$query);
if($data){
	echo "Data delete succesfully";
	
}
else{
	echo"something wrong";
}
?>