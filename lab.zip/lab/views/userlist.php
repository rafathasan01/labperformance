<?php
include("db.php");
$query="SELECT * FROM users  ";
$conn = getConnection();
$data= mysqli_query($conn,$query);
$total=mysqli_num_rows($data);



?>

<!DOCTYPE html>
<html>
<head>
	<title>User List</title>
</head>
<body>

	<h2>User List</h2>
	<a href="home.php">Back</a> |
	<a href="logout.php">logout</a>

	<br>
	<br>

	<table border="1" >
		<tr>
		     <th>Employee Name</th>
			<th>Contact</th>
			<th>UserName</th>
			<th>Password</th>
			
			<th>Type</th> 
		</tr>
		
		<?php
		while($result=mysqli_fetch_assoc($data))
		{
			echo "<tr>
		     <td>".$result['ename']."</td>
			<td> ".$result['contact']."</td>
			<td>".$result['uname']."</td>
			<td>".$result['pass']."</td>
			
			<td>".$result['type']."</td>
			<td><a href='edit.php?id=$result[ename]&ur=$result[contact]&em=$result[uname]&ps=$result[pass]&tp=$result[type]'>EDIT</a></td>
			<td><a href='delete.php?id=$result[id]'>DELETE</a></td>
			</tr>";
				
		}
				?>
			
		</tr>
		
	
	</table>
</body>
</html>