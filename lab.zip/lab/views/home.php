<?php
	//session_start();
	if(isset($_COOKIE['ename'])){
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>

	<h1>Welcome Home! <?=$_COOKIE['ename']?></h1> 
	
	<a href="userlist.php">User List</a> | 
	<a href="adduser.php">Add User</a> | 
	<a href="../php/logout.php">logout</a>

</body>	
</html>


<?php		
	}else{
		header('location: login.php');
	}

?>

