
<?php

include("db.php");
error_reporting(0);



?>

<html>
<head>
	<title>Edit/update user</title>
</head>
<body>
<form method="POST" >
<center>
<table border="1" width="50%" height="50%">
	<tr>
		<td align="right"><a href="home.php">Home</a> | <a href="logout.php">Logout</a> </td>
	</tr>
	<tr>
		<td colspan="2" align="center">
			<br>
			<fieldset>
				<legend><h3>Update User</h3></legend>
				
					<table border="0" width="80%">
						<tr>
							<td>
								Employee Name
							</td>
							<td align="right">
								:<input type="text" name="ename" value="<?php echo $_GET['ename'];?>">
							</td>
						</tr>
						<tr>
							<td colspan="2"><hr></td>
						</tr>
						
						<tr>
							<td>
								Contact
							</td>
							<td align="right">
								:<input type="text" name="contact" value="<?php echo $_GET['contact'];?>">
							</td>
						</tr>
						<tr>
							<td colspan="2"><hr></td>
						</tr>
						
						<tr>
							<td>
								<p>UserName</p>
							</td>
							<td align="right">
								:<input type="text" name="uname" value="<?php echo $_GET['uname']; ?>">
							</td>
						</tr>
						<tr>
							<td colspan="2"><hr></td>
						</tr>
						
						
						<tr>
							<td>
								Password
							</td>
							<td align="right">
								:<input type="password" name="pass" value="<?php echo $_GET['pass'];?>">
							</td>
						</tr>
						
						
						
						<!--<tr>
							<td colspan="2">
								<fieldset>
									<legend><h4>GENDER</h4></legend>
									<input type="checkbox" name="gender">Male<input type="checkbox" name="gender">Female<input type="checkbox" name="gender">Other
								</fieldset>
							</td>
						</tr>-->
						<tr>
							<td colspan="2"><hr></td>
						</tr>
						
						<tr>
							<td colspan="2"><hr></td>
						</tr>
						<tr>
							<td colspan="2"><input type="Submit" name="submit" value="UPDATE"> <input type="reset" name="reet"></td>
						</tr>
					</table>
			
			</fieldset>
		</td>
	</tr>
</table>
</center>
	</form>
	<?php
	if($_POST['submit'])
	{
		$ename=$_POST['ename'];
		$contact=$_POST['contact'];
		$uname=$_POST['uname'];
		$pass=$_POST['pass'];
		
		$query="UPDATE users SET ename='$ename',contact='$contact',uname='$uname', pass='$pass' WHERE uname='$uname'";
	$conn = getConnection();	
	$data=mysqli_query($conn,$query);
	if($data){
		echo"<font color=green>record update seccessfuly. <a href='userlist.php'>Check employee details</a>";
		
		
	}
	else{
		
		echo"record don't update";
		
	}
	}
	else{
		
		echo"something wrong";
		
	}
	
	?>
</body>
</html>


