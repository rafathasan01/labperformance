<?php
	//session_start();
	if(isset($_COOKIE['username'])){
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>

	<h1>Add New User</h1> 
	
	<a href="home.php">Back</a> |  
	<a href="../php/logout.php">logout</a>

	<form method="post" action="../php/insertUser.php">
		<table>
			<tr>
				<td>Employee Name:</td>
				<td><input type="text" name="ename"></td>
			</tr>
			<tr>
				<td>Contact:</td>
				<td><input type="text" name="contact"></td>
			</tr>
			<tr>
				<td>UserName:</td>
				<td><input type="text" name="uname"></td>
			</tr>
			<tr>
				<td>Password:</td>
				<td><input type="password" name="pass"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Save"></td>
			</tr>
		</table>
	</form>


</body>	
</html>



<?php		
	}else{
		header('location: login.html');
	}

?>

