<?php
	
	require_once('functions.php');

	if(isset($_POST['submit'])){

		$ename = $_POST['ename'];
		$contact = $_POST['contact'];
		$uname = $_POST['uname'];
		$pass = $_POST['pass'];

		if(empty($ename) == true || empty($contact) == true || empty($uname) == true || empty($pass) == true){
			echo "null submission!";
		}else{

			$status = register($ename, $contact, $uname, $pass);

			if($status){

				header('location: ../views/login.php?msg=success');
			}else{
				header('location: ../views/reg.php?msg=dberror');
			}
		}

	}else{
		header('location: ../views/reg.php');
	}


?>