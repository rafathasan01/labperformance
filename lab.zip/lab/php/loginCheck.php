<?php
	session_start();
	require_once('functions.php');
	//define(name, value)
	
	if(isset($_POST['submit'])){

		$uname = $_POST['uname'];
		$pass = $_POST['pass'];

		if(empty($uname) == true || empty($pass) == true){
			echo "null submission!";
		}else{

			$count = validate($uname, $pass);

			if($count > 0){
				
				$_SESSION['uname'] = $uname;
				$_SESSION['pass'] = $pass;

				setcookie("uname", $uname, time()+3600, "/");
				header('location: ../views/home.php');

			}else{
				echo "invalid username/password";
			}
		}
	}else{
		header('location: ../views/login.php');
	}


?>