<?php
	require_once('db.php');

	function validate($uname, $pass){

		$conn = getConnection();
		
		$sql = "select * from users where uname='{$uname}' and pass='{$pass}'";

		$result = mysqli_query($conn, $sql);
		$user = mysqli_fetch_assoc($result);

		return count($user);
	}


	function register($ename, $contact, $uname, $pass){

		$conn = getConnection();
		$sql = "insert into users values('{$ename}','{$contact}', '{$uname}','($pass)' 0)";

		if(mysqli_query($conn, $sql)){
			return true;
		}else{
			return false;
		}

	}

?>